# Issue 3619387 — Sidebar errors (indicator + modal behavior)

Review bundle. Unzip and load the files below.

## Contents
- `3619387-sidebar-errors-full.patch` — full patch vs branch base (HEAD). Uploadable for quick evaluation.
- `sidebar-errors-full.patch` — same full patch (copy).
- `sidebar-errors-interdiff.patch` — interdiff vs `patches/core-a11y-aggregate-2026-07-20.patch` (the "last patch"). `Helper.php` is omitted because its has-error work is already in the aggregate; the interdiff shows the delta beyond it.
- `sidebar-errors-comment.md` — proposed issue-queue comment describing the change.
- `src/` — copies of the changed source files for direct review (no patching needed).
- `guidepup/` — before/after screen-reader harness:
  - `sidebar-modal.voiceover.mjs` — Guidepup/VoiceOver script (run on macOS).
  - `README.md` — install/run instructions; diff the before/after logs.
  - `ANALYSIS.md` — expected before/after screen-reader behavior.

## What changed
1. Error indicator on the sidebar toggle when the advanced group has child errors (`has-error` class, `aria-invalid`, visually-hidden "has errors").
2. Modal behavior when the sidebar overlays content (narrow viewports): background `inert` + `aria-hidden`, focus trapped, `role="dialog"`/`aria-modal`, `Esc` to close, focus returned to the toggle.
3. Removed a duplicate "Close sidebar panel" link — one toggle control opens and closes.
4. `SidebarChildErrorsTest` added.

## Verify locally
```
# Drupal tests
ddev exec env SIMPLETEST_BASE_URL=https://drupal-core.ddev.site \
  ./vendor/bin/phpunit -c core core/themes/default_admin/tests/src/Functional/SidebarChildErrorsTest.php

# Code quality
ddev exec bash ./core/scripts/dev/commit-code-check.sh

# Screen reader (macOS host)
cd guidepup && npm i -D @guidepup/guidepup playwright && npx playwright install chromium
node guidepup/sidebar-modal.voiceover.mjs > before.txt   # unpatched
# apply patch, clear caches, then:
node guidepup/sidebar-modal.voiceover.mjs > after.txt
diff before.txt after.txt
```
